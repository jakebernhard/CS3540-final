using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelManager : MonoBehaviour
{
    public float levelDuration = 10.0f;
    public Text timerText;
    public Text gameText;
    float countdown;
    public static bool isGameOver = false;
   

    // Start is called before the first frame update
    void Start()
    {
        isGameOver = false;
        countdown = levelDuration;
        SetTimerText();
    }

    // Update is called once per frame
    void Update()
    {
        if (!isGameOver && BeehiveBehavior.gameStarted)
        {
            if (countdown > 0)
            {
                countdown -= Time.deltaTime;
            }
            else
            {
                countdown = 0.0f;
                LevelBeat();
            }
            SetTimerText();
        }
    }

    void SetTimerText()
    {
        timerText.text = countdown.ToString("f2");
    }

    public void LevelLost()
    {
        isGameOver = true;
        gameText.text = "GAME OVER!";
        gameText.gameObject.SetActive(true);
    }

    public void LevelBeat()
    {
        isGameOver = true;
        gameText.text = "YOU WIN!";
        gameText.gameObject.SetActive(true);
    }

}

