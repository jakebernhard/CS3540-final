using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeehiveBehavior : MonoBehaviour
{
    public Transform player;

    public GameObject bee;

    public int beeNumber;

    public static bool gameStarted;

    int beeCurrent;



    // Start is called before the first frame update
    void Start()
    {

        gameStarted = false;
        beeCurrent = beeNumber;
        if (player == null)
        {
            player = GameObject.FindGameObjectWithTag("Player").transform;
        }
    }

    // Update is called once per frame
    void Update()
    {

        float distance = Vector3.Distance(transform.position, player.position);

        if (distance < 7)
        {
            gameStarted = true;

            if (beeCurrent > 0)
            {
                Vector3 randomPosition = transform.position + Random.insideUnitSphere * 2;
                GameObject enemy = Instantiate(bee, randomPosition, transform.rotation) as GameObject;
                beeCurrent--;
            }

        }

    }
}
